Một dự án mẫu nằm trong các bài toán Nông nghiệp thông minh
